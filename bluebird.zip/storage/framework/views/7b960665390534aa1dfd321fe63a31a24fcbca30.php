<?php $__env->startSection('title', 'Bank Cards'); ?>
<?php $__env->startSection('page_css'); ?>
<!-- BEGIN: Vendor CSS-->
<link rel="stylesheet" type="text/css" href="/admin_assets/app-assets/vendors/css/vendors.min.css">
<link rel="stylesheet" type="text/css" href="/admin_assets/app-assets/vendors/css/tables/datatable/datatables.min.css">
<!-- END: Vendor CSS-->

<!-- BEGIN: Theme CSS-->
<link rel="stylesheet" type="text/css" href="/admin_assets/app-assets/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="/admin_assets/app-assets/css/bootstrap-extended.min.css">
<link rel="stylesheet" type="text/css" href="/admin_assets/app-assets/css/colors.min.css">
<link rel="stylesheet" type="text/css" href="/admin_assets/app-assets/css/components.min.css">
<!-- END: Theme CSS-->

<!-- BEGIN: Page CSS-->
<link rel="stylesheet" type="text/css" href="/admin_assets/app-assets/css/core/menu/menu-types/horizontal-menu.min.css">
<link rel="stylesheet" type="text/css" href="/admin_assets/app-assets/css/core/colors/palette-gradient.min.css">
<link rel="stylesheet" type="text/css" href="/admin_assets/app-assets/css/pages/single-page.min.css">
<!-- END: Page CSS-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_css'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<!-- BEGIN: Content-->
<div class="app-content content">
  <div class="content-overlay"></div>
  <div class="content-wrapper">
    
    <div class="content-header row">
      <div class="content-header-left col-md-6 col-12 mb-2">
        <h3 class="content-header-title">Cards List</h3>
        <div class="row breadcrumbs-top">
          <div class="breadcrumb-wrapper col-12">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a>
              </li>
              <li class="breadcrumb-item"><a href="<?php echo e(route('cards.index')); ?>">Accounts</a>
              </li>
              <li class="breadcrumb-item active">Cards List
              </li>
            </ol>
          </div>
        </div>
      </div>
    </div>

    <div class="content-body">
      <!-- Base style table -->
      <section id="base-style">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h4 class="card-title float-left">My Cards</h4>
                <div class="float-right">
                  
                  <div class="modal fade text-left" id="inlineForm" tabindex="-1" role="dialog" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                      <div class="modal-content">
                        <div class="modal-header">
                          <label class="modal-title text-text-bold-600" id="myModalLabel33">Credit Card Details</label>
                        </div>
                        <form action="#">
                          <div class="modal-body">
                            <label>Holder Name
                              <span class="danger">*</span>
                            </label>
                            <div class="form-group">
                              <input type="text" placeholder="Holder Name" name="holder-name" class="form-control">
                            </div>

                            <label>Card Number
                              <span class="danger">*</span>
                            </label>
                            <div class="form-group">
                              <input type="text" placeholder="Card Number" name="card-no" class="form-control">
                            </div>

                            

                            <label>Card Balance </label>
                            <div class="form-group">
                              <input type="text" placeholder="Credit Limit" name="limit" class="form-control" />
                            </div>

                            <label for="status">Card Status
                              <span class="danger">*</span>
                            </label>
                            <div class="form-group">
                              <select class="c-select form-control" id="status" name="card-status">
                                <option value="Active">Active</option>
                                <option value="Deactived">Deactived</option>
                                <option value="Delayed">Delayed</option>
                                <option value="Surrendered">Surrendered</option>
                              </select>
                            </div>
                          </div>
                          <div class="modal-footer">
                            <input type="submit" class="btn btn-success" value="Submit">
                            <input type="reset" class="btn btn-danger" data-dismiss="modal" value="Cancel">
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="card-body mt-1">
                <div class="table-responsive">
                  <table id="active-accounts" class="table alt-pagination card-wrapper">
                    <thead>
                      <tr>
                        <th class="border-top-0">PAN</th>
                        <th class="border-top-0">Card No.</th>
                        <th class="border-top-0">CVV</th>
                        <th class="border-top-0">Holder Name</th>
                        <th class="border-top-0">Expiry Date</th>
                        
                        <th class="border-top-0">Credit Balance</th>
                        <th class="border-top-0">Status</th>
                        <th class="border-top-0">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td class="align-middle">
                              <div class="card-icon"><?php echo e($card->pan ?? 'Debit'); ?></div>
                            </td>
                            <td class="align-middle">
                              <div class="card-no"><i class="la la-credit-card text-light"></i>
                                <?php echo e($card->card_num); ?>

                              </div>
                            </td>

                            <td class="align-middle">
                              <div class="card-no"><?php echo e($card->cvv); ?></div>
                            </td>


                            <td class="align-middle">
                              <div class="holder-name"><?php echo e(auth()->user()->profile->getFullName()); ?></div>
                            </td>
                            <td class="align-middle">
                              <div class="exp-date"><?php echo e($card->expiry); ?></div>
                            </td>
                            
                            <td class="align-middle">
                              <div class="ac-balance">
                                <span>$</span> <?php echo e($card->balance > 0 ? $card->balance : '0.00'); ?>

                              </div>
                            </td>

                            <td class="align-middle">
                              <div class="ac-status badge 
                                <?php if($card->status): ?> badge-success <?php else: ?> badge-danger <?php endif; ?> 
                                badge-pill badge-sm">
                                <?php if($card->status): ?> Active <?php else: ?> Deactivated <?php endif; ?>
                              </div>
                            </td>

                            <td class="d-flex">
                              <div class="action">
                                <a href="<?php echo e(route('cards.edit', $card->id)); ?>"><i class="la la-pencil-square success"></i></a>
                              </div>
                              
                            </td>

                          </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     
                      
                      
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  </div>
</div>
<!-- END: Content-->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_js'); ?>
<!-- BEGIN: Vendor JS-->
<script src="/admin_assets/app-assets/vendors/js/vendors.min.js"></script>
<!-- BEGIN Vendor JS-->

<!-- BEGIN: Page Vendor JS-->
<script src="/admin_assets/app-assets/vendors/js/ui/jquery.sticky.js"></script>
<script src="/admin_assets/app-assets/vendors/js/charts/jquery.sparkline.min.js"></script>



<!-- END: Page Vendor JS-->

<!-- BEGIN: Theme JS-->
<script src="/admin_assets/app-assets/js/core/app-menu.min.js"></script>
<script src="/admin_assets/app-assets/js/core/app.min.js"></script>
<script src="/admin_assets/app-assets/js/scripts/customizer.min.js"></script>
<script src="/admin_assets/app-assets/js/scripts/footer.min.js"></script>
<!-- END: Theme JS-->

<!-- BEGIN: Page JS-->
<script src="/admin_assets/app-assets/js/scripts/ui/breadcrumbs-with-stats.min.js"></script>
<script src="/admin_assets/app-assets/js/scripts/pages/bank-cards.min.js"></script>
<!-- END: Page JS-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dan/repo/monobank/resources/views/admin/cards/index.blade.php ENDPATH**/ ?>