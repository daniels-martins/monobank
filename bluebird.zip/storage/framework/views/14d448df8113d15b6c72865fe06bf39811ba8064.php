

<img src="/static_assets/img/blue-bird-logo-1.svg"   alt="" width="200" height="52" />


<?php /**PATH /home/dan/repo/monobank/resources/views/components/application-logo.blade.php ENDPATH**/ ?>