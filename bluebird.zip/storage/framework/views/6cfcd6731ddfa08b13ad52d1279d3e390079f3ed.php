<!-- BEGIN: Custom CSS-->
<link rel="stylesheet" type="text/css" href="/admin_assets/assets/css/style.css">
<!-- END: Custom CSS--><?php /**PATH /home/dan/repo/monobank/resources/views/admin/partials/udo_css.blade.php ENDPATH**/ ?>