<?php $__env->startSection('title', 'Accounts'); ?>
<?php $__env->startSection('page_css'); ?>
<!-- BEGIN: Vendor CSS-->
<link rel="stylesheet" type="text/css" href="/admin_assets/app-assets/vendors/css/vendors.min.css">
<link rel="stylesheet" type="text/css" href="/admin_assets/app-assets/vendors/css/tables/datatable/datatables.min.css">
<!-- END: Vendor CSS-->

<!-- BEGIN: Theme CSS-->
<link rel="stylesheet" type="text/css" href="/admin_assets/app-assets/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="/admin_assets/app-assets/css/bootstrap-extended.min.css">
<link rel="stylesheet" type="text/css" href="/admin_assets/app-assets/css/colors.min.css">
<link rel="stylesheet" type="text/css" href="/admin_assets/app-assets/css/components.min.css">
<!-- END: Theme CSS-->

<!-- BEGIN: Page CSS-->
<link rel="stylesheet" type="text/css" href="/admin_assets/app-assets/css/core/menu/menu-types/horizontal-menu.min.css">
<link rel="stylesheet" type="text/css" href="/admin_assets/app-assets/css/core/colors/palette-gradient.min.css">
<link rel="stylesheet" type="text/css" href="/admin_assets/app-assets/css/pages/single-page.min.css">
<!-- END: Page CSS-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_css'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<!-- BEGIN: Content-->
<div class="app-content content">
  <div class="content-overlay"></div>
  <div class="content-wrapper">
    <div class="content-header row">
      <div class="content-header-left col-md-6 col-12 mb-2">
        <h3 class="content-header-title">All Accounts</h3>
        <div class="row breadcrumbs-top">
          <div class="breadcrumb-wrapper col-12">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a>
              </li>
              <li class="breadcrumb-item"><a href="<?php echo e(route('accounts.index')); ?>">Accounts</a>
              </li>
              <li class="breadcrumb-item active">All Accounts
              </li>
            </ol>
          </div>
        </div>
      </div>
      <div class="content-header-right col-md-6 col-12">
        <div class="media width-250 float-right">
          <media-left class="media-middle">
            <div id="sp-bar-total-sales"></div>
          </media-left>
          <div class="media-body media-right text-right">
            <h3 class="m-0">$<?php echo e(auth()->user()->azaBalSavings()); ?></h3><span class="text-muted">Balance</span>

          </div>
        </div>
      </div>
    </div>
    <div class="content-body">
      <!-- Base style table -->
      <section id="base-style">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h4 class="card-title float-left">
                  Accounts Summary
                </h4>
                <div class="float-right">
                  
                </div>
              </div>
              <div class="card-body mt-1">
                <div class="table-responsive">
                  <table id="active-accounts" class="table alt-pagination table-wrapper">
                    <thead>
                      <tr>
                        <th class="border-top-0"></th>
                        <th class="border-top-0">Type</th>
                        <th class="border-top-0">A/c Number</th>
                        <th class="border-top-0">Holder Name</th>
                        <th class="border-top-0">Status</th>
                        <th class="border-top-0">Balance</th>
                        <th class="border-top-0">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = auth()->user()->azas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td class="align-middle">
                          <div class="ac-symbol 
                            <?php echo e($account->getType() == 'savings' 
                                ? substr($account->getType(),0,-1) 
                                : $account->getType()); ?> ">
                            <?php switch($account->getType()):
                            case ('savings'): ?>
                            <i class="la la-suitcase"></i>
                            <?php break; ?>
                            
                            <?php case ('loan'): ?>
                            <i class="la la-money"></i>
                            <?php break; ?>

                            <?php case ('current'): ?>
                            <?php case ('checking'): ?>
                            <i class="la la-street-view"></i>
                            <?php break; ?>

                            <?php case ('joint'): ?>
                            <i class="la la-users"></i>
                            <?php break; ?>
                            <?php endswitch; ?>
                          </div>
                        </td>
                        <td class="align-middle">
                          <div class="ac-type">
                            <?php echo e(ucfirst($account->getType())); ?>

                          </div>
                        </td>
                        <td class="align-middle">
                          <div class="ac-number">
                            <?php echo e($account->num); ?>

                          </div>
                        </td>
                        <td class="align-middle">
                          <div class="ac-hol-name">
                            <?php echo e($account->getOwner()); ?>

                          </div>
                        </td>
                        <td class="align-middle">
                          <div class="ac-status badge 
                            <?php if($account->status): ?> badge-success <?php else: ?> badge-danger <?php endif; ?> 
                            badge-pill badge-sm">
                            <?php if($account->status): ?> Active <?php else: ?> Inactive <?php endif; ?>
                          </div>
                        </td>
                        <td class="align-middle">
                          <div class="ac-balance">
                            <span>$</span> <?php echo e($account->balance > 0 ? $account->balance : '0.00'); ?>

                          </div>
                        </td>

                        <td class="d-flex">
                          <div>
                            <a title="Edit" href="<?php echo e(route('accounts.edit', $account->id)); ?>">
                              <i class="la la-pencil-square success"></i>
                            </a>
                          </div>

                          
                        </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  </div>
</div>
<!-- END: Content-->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_js'); ?>
<!-- BEGIN: Vendor JS-->
<script src="/admin_assets/app-assets/vendors/js/vendors.min.js"></script>
<!-- BEGIN Vendor JS-->

<!-- BEGIN: Page Vendor JS-->
<script src="/admin_assets/app-assets/vendors/js/ui/jquery.sticky.js"></script>
<script src="/admin_assets/app-assets/vendors/js/charts/jquery.sparkline.min.js"></script>



<!-- END: Page Vendor JS-->

<!-- BEGIN: Theme JS-->
<script src="/admin_assets/app-assets/js/core/app-menu.min.js"></script>
<script src="/admin_assets/app-assets/js/core/app.min.js"></script>
<script src="/admin_assets/app-assets/js/scripts/customizer.min.js"></script>
<script src="/admin_assets/app-assets/js/scripts/footer.min.js"></script>
<!-- END: Theme JS-->

<!-- BEGIN: Page JS-->
<script src="/admin_assets/app-assets/js/scripts/ui/breadcrumbs-with-stats.min.js"></script>
<script src="/admin_assets/app-assets/js/scripts/pages/bank-accounts.min.js"></script>
<!-- END: Page JS-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dan/repo/monobank/resources/views/admin/accounts/index.blade.php ENDPATH**/ ?>