<div class="header-navbar navbar-expand-sm navbar navbar-horizontal navbar-fixed navbar-dark navbar-without-dd-arrow navbar-shadow"
    role="navigation" data-menu="menu-wrapper">
    <div class="navbar-container main-menu-content" data-menu="menu-container">
        <ul class="nav navbar-nav" id="main-menu-navigation" data-menu="menu-navigation">
            <li class="nav-item active"><a class="nav-link" href="<?php echo e(route('dashboard')); ?>"><i
                        class="la la-bank"></i><span>Account Dashboard</span></a></li>
            
            <li class="dropdown nav-item <?php if(Route::currentRoutename() == 'accounts.index'): ?> bg-danger <?php endif; ?>" data-menu="dropdown">
                <a class="dropdown-toggle nav-link" href="<?php echo e(route('accounts.index')); ?>">Account Information</a>
            </li>

            


            <li class="dropdown <?php if(Route::currentRoutename() == 'cards.index'): ?> bg-danger <?php endif; ?> nav-item" data-menu="dropdown">
                <a class="dropdown-toggle nav-link" href="<?php echo e(route('cards.index')); ?>">Cards</a>
            </li>
            
            <li class="dropdown <?php if(Route::currentRoutename() == 'transactions.index'): ?> bg-danger <?php endif; ?>  nav-item" data-menu="dropdown">
                <a class="dropdown-toggle nav-link" href="<?php echo e(route('transactions.index')); ?>">Transactions</a>
            </li>

            <li class="dropdown <?php if(Route::currentRoutename() == 'profile.edit'): ?> bg-danger <?php endif; ?>  nav-item" data-menu="dropdown">
                <a class="dropdown-toggle nav-link" href="<?php echo e(route('profile.edit')); ?>">Profile</a>
            </li>

            <li class="dropdown d-flex <?php if(Route::currentRoutename() == 'payments.create'): ?> bg-danger <?php endif; ?>  nav-item"
                data-menu="dropdown">
                <a class="dropdown-toggle nav-link" href="<?php echo e(route('payments.create')); ?>"> Send Money</a> <i
                    class="la la-send text-white"></i>
            </li>

            <li class="dropdown d-flex <?php if(Route::currentRoutename() == 'deposit.create'): ?> bg-danger <?php endif; ?>  nav-item"
                data-menu="dropdown">
                <a class="dropdown-toggle nav-link" href="<?php echo e(route('deposit.create')); ?>"> Add Money</a> <i
                    class="la la-plus text-white"></i>
            </li>

        </ul>
    </div>
</div>
<?php /**PATH /home/dan/repo/monobank/resources/views/admin/partials/main_menu.blade.php ENDPATH**/ ?>