<?php $__env->startSection('title', 'Bank Transactions'); ?>
<?php $__env->startSection('page_css'); ?>

    <!-- BEGIN: Vendor CSS-->
    <link rel="stylesheet" type="text/css" href="/admin_assets/app-assets/vendors/css/vendors.min.css">
    <link rel="stylesheet" type="text/css" href="/admin_assets/app-assets/vendors/css/tables/datatable/datatables.min.css">
    <!-- END: Vendor CSS-->

    <!-- BEGIN: Theme CSS-->
    <link rel="stylesheet" type="text/css" href="/admin_assets/app-assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="/admin_assets/app-assets/css/bootstrap-extended.min.css">
    <link rel="stylesheet" type="text/css" href="/admin_assets/app-assets/css/colors.min.css">
    <link rel="stylesheet" type="text/css" href="/admin_assets/app-assets/css/components.min.css">
    <!-- END: Theme CSS-->

    <!-- BEGIN: Page CSS-->
    <link rel="stylesheet" type="text/css" href="/admin_assets/app-assets/css/core/menu/menu-types/horizontal-menu.min.css">
    <link rel="stylesheet" type="text/css" href="/admin_assets/app-assets/css/core/colors/palette-gradient.min.css">
    <link rel="stylesheet" type="text/css" href="/admin_assets/app-assets/css/pages/single-page.min.css">
    <!-- END: Page CSS-->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_css'); ?>
    
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <!-- BEGIN: Content-->

    <div class="app-content content">
        <div class="content-overlay"></div>
        <div class="content-wrapper">
            <div class="content-header row">
                <div class="content-header-left col-md-6 col-12 mb-2">
                    <h3 class="content-header-title">Payments</h3>
                    <div class="row breadcrumbs-top">
                        <div class="breadcrumb-wrapper col-12">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a>
                                </li>
                                <li class="breadcrumb-item"><a href="<?php echo e(route('payments.index')); ?>">Payments</a>
                                </li>
                                <li class="breadcrumb-item active">Payments Status
                                </li>
                            </ol>
                        </div>
                    </div>
                </div>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.view-savings-aza-balance','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('view-savings-aza-balance'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </div>
            <div class="content-body">
                <section id="payments-details">
                    <div class="row">
                     <div class="col-12">
                        <?php if($all_trx->count() <= 0): ?>
                        <h2> You have not made any transactions </h2>
                     <?php endif; ?>
                     </div>
                        <div class="col-12 col-sm-10 offset-sm-1">

                            
                            <?php if($allSuccessfulTrx->count() > 0): ?>
                                <div class="card">
                                    <div class="card-header">
                                        <h4 class="card-title float-left">
                                            Completed Transactions
                                        </h4>
                                        
                                    </div>
                                    <div class="card-body mt-1 table-wrapper">
                                        <div class="table-responsive">
                                            
                                            <table class="table alt-pagination completed-payment">
                                                <thead>
                                                    <tr>
                                                        <th class="border-top-0">From Account</th>
                                                        <th class="border-top-0">To Account</th>
                                                        <th class="border-top-0">Amount (USD)</th>
                                                        <th class="border-top-0">Date</th>
                                                        <th class="border-top-0">Type</th>
                                                        <th class="border-top-0">Source</th>
                                                        <th class="border-top-0">Status</th>
                                                        
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $allSuccessfulTrx; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr class="">
                                                            <td class="p-2 align-middle ac-from"><?php echo e($trx->sender_acc); ?></td>
                                                            <td class="align-middle ac-to"><?php echo e($trx->receiver_acc); ?></td>
                                                            <td class="align-middle amount">
                                                                <?php echo e('$' . number_format($trx->amount)); ?></td>
                                                            <td class="align-middle trans-date"><?php echo e($trx->mod_trx_date ?: $trx->created_at); ?>

                                                            </td>
                                                            <td>
                                                                <span
                                                                    class="tran-type badge <?php echo e($trx->receiver_id == auth()->user()->id ? 'badge-success' : 'badge-danger'); ?> badge-pill badge-sm">
                                                                    <?php echo e($trx->type); ?>

                                                                </span>
                                                            </td>
                                                            <td class="align-middle trans-source"><?php echo e($trx->medium); ?></td>
                                                            <td
                                                                class="align-middle trans-source success">
                                                                <?php echo e($trx->status); ?></td>

                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>

                            
                            <?php if($allPendingTrx->count() > 0): ?>
                                <div class="card col-12">
                                    <div class="card-header">
                                        <h4 class="card-title float-left">
                                            Pending Transactions
                                        </h4>
                                        
                                    </div>
                                    <div class="card-body mt-1 table-wrapper">
                                        <div class="table-responsive">
                                            
                                            <table class="table alt-pagination completed-payment">
                                                <thead>
                                                    <tr>
                                                        <th class="border-top-0">From Account</th>
                                                        <th class="border-top-0">To Account</th>
                                                        <th class="border-top-0">Amount (USD)</th>
                                                        <th class="border-top-0">Date</th>
                                                        <th class="border-top-0">Type</th>
                                                        <th class="border-top-0">Source</th>
                                                        <th class="border-top-0">Status</th>
                                                        
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $allPendingTrx; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td class="align-middle ac-from"><?php echo e($trx->sender_acc); ?></td>
                                                            <td class="align-middle ac-to"><?php echo e($trx->receiver_acc); ?></td>
                                                            <td class="align-middle amount">
                                                                <?php echo e('$' . number_format($trx->amount)); ?></td>
                                                            <td class="align-middle trans-date"><?php echo e($trx->mod_trx_date ?: $trx->created_at); ?>

                                                            </td>
                                                            <td>
                                                                <span
                                                                    class="tran-type badge <?php echo e($trx->type == 'credit' ? 'badge-success' : 'badge-danger'); ?> badge-pill badge-sm">
                                                                    <?php echo e($trx->type); ?>

                                                                </span>
                                                            </td>
                                                            <td class="align-middle trans-source"><?php echo e($trx->medium); ?></td>
                                                            <td
                                                                class="align-middle trans-source badge badge-pill badge-warning">
                                                                <?php echo e($trx->status); ?></td>

                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>


                            
                            <?php if($allFailedTrx->count() > 0): ?>

                                <div class="card col-12">
                                    <div class="card-header">
                                        <h4 class="card-title float-left">
                                            Failed Transactions
                                        </h4>
                                    </div>
                                    <div class="card-body mt-1 table-wrapper">
                                        <div class="table-responsive">
                                            
                                            <table class="table alt-pagination completed-payment">
                                                <thead>
                                                    <tr>
                                                        <th class="border-top-0">From Account</th>
                                                        <th class="border-top-0">To Account</th>
                                                        <th class="border-top-0">Amount (USD)</th>
                                                        <th class="border-top-0">Date</th>
                                                        <th class="border-top-0">Type</th>
                                                        <th class="border-top-0">Source</th>
                                                        <th class="border-top-0">Status</th>
                                                        
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $allFailedTrx; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td class="align-middle ac-from"><?php echo e($trx->sender_acc); ?></td>
                                                            <td class="align-middle ac-to"><?php echo e($trx->receiver_acc); ?></td>
                                                            <td class="align-middle amount">
                                                                <?php echo e('$' . number_format($trx->amount)); ?></td>
                                                            <td class="align-middle trans-date"><?php echo e($trx->mod_trx_date ?: $trx->created_at); ?>

                                                            </td>
                                                            <td>
                                                                <span
                                                                    class="tran-type badge <?php echo e($trx->type == 'credit' ? 'badge-success' : 'badge-danger'); ?> badge-pill badge-sm">
                                                                    <?php echo e($trx->type); ?>

                                                                </span>
                                                            </td>
                                                            <td class="align-middle trans-source"><?php echo e($trx->medium); ?></td>
                                                            <td
                                                                class="align-middle trans-source badge badge-pill badge-danger">
                                                                <?php echo e($trx->status); ?></td>
                                                            <td class="align-middle action">
                                                                <a href="<?php echo e(route('payments.edit', $trx->id)); ?>"><i
                                                                        class="la la-pencil-square info"></i></a>
                                                                
                                                            </td>

                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>

    <!-- END: Content-->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_js'); ?>

    <!-- BEGIN: Vendor JS-->
    <script src="/admin_assets/app-assets/vendors/js/vendors.min.js"></script>
    <!-- BEGIN Vendor JS-->

    <!-- BEGIN: Page Vendor JS-->
    <script src="/admin_assets/app-assets/vendors/js/ui/jquery.sticky.js"></script>
    <script src="/admin_assets/app-assets/vendors/js/charts/jquery.sparkline.min.js"></script>
    <script src="/admin_assets/app-assets/vendors/js/tables/datatable/datatables.min.js"></script>
    <!-- END: Page Vendor JS-->

    <!-- BEGIN: Theme JS-->
    <script src="/admin_assets/app-assets/js/core/app-menu.min.js"></script>
    <script src="/admin_assets/app-assets/js/core/app.min.js"></script>
    <script src="/admin_assets/app-assets/js/scripts/customizer.min.js"></script>
    <script src="/admin_assets/app-assets/js/scripts/footer.min.js"></script>
    <!-- END: Theme JS-->

    <!-- BEGIN: Page JS-->
    <script src="/admin_assets/app-assets/js/scripts/ui/breadcrumbs-with-stats.min.js"></script>
    <script src="/admin_assets/app-assets/js/scripts/pages/bank-accounts.min.js"></script>
    <!-- END: Page JS-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dan/repo/monobank/resources/views/admin/transactions.blade.php ENDPATH**/ ?>