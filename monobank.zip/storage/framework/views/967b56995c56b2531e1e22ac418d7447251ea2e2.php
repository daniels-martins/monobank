
<?php /**PATH /home/dan/repo/monobank/resources/views/components/view-savings-aza-balance.blade.php ENDPATH**/ ?>