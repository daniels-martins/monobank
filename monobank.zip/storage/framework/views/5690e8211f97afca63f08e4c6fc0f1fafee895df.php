<?php echo e($slot); ?>

<?php /**PATH /home/dan/repo/monobank/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>