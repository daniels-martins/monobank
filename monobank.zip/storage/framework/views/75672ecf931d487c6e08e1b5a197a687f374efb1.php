<div class="card card-rounded">
    <div class="card-body">
        <div class="d-sm-flex justify-content-between align-items-start">
            <div>
                <h4 class="card-title card-title-dash">
                    Most Recent Transactions (All)
                </h4>
                <p class="card-subtitle card-subtitle-dash">
                    
                </p>
            </div>
            <div>
                <a href="<?php echo e(route('payments.index')); ?>">
                    <button class="btn btn-primary btn-lg text-white mb-0 me-0" type="button">
                        <i class="typcn text-white typcn-eye"></i>
                        View All
                    </button>
                </a>
            </div>
        </div>
        <div class="table-responsive mt-1">
            <table class="table select-table">
                <thead>
                    <tr>
                        <th>Amount</th>
                        <th>Description</th>
                        
                        <th>Status</th>
                        <th>Date/time</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = auth()->user()->trx()->sortBy('created_at', SORT_REGULAR, true)->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>

                            <td class="text-truncate">
                                <?php if (! ($trx->receiver_id == auth()->user()->id)): ?>
                                    
                                    <i class="ft-arrow-down-right danger"></i>
                                <?php else: ?>
                                    
                                    <i class="ft-arrow-up-right success"></i>
                                <?php endif; ?>
                                <SPAN class="<?php echo e($trx->receiver_id == auth()->user()->id ? 'text-success' : ''); ?>">
                                    <b>
                                        <?php echo e($trx->receiver_id == auth()->user()->id ? '+' : '-'); ?>

                                        $<?php echo e(number_format($trx->amount, 2)); ?>

                                    </b>
                                </SPAN>
                                <div class="font-small-2 text-light">
                                    <i class="font-small-2 ft-map-pin"></i>
                                    <?php echo e($trx->medium); ?>

                                </div>
                            </td>


                            <td>
                                <h6><?php echo e($trx->desc() ?: 'deposit'); ?></h6>
                                
                            </td>

                            <td class="text-truncate mt-1">
                                <?php if($trx->status == 'successful'): ?>
                                    <div class="badge badge-opacity-success"><?php echo e($trx->status); ?></div>
                                <?php elseif($trx->status == 'pending'): ?>
                                    <div class="badge badge-opacity-warning"><?php echo e($trx->status); ?></div>
                                <?php else: ?>
                                    <div class="badge badge-opacity-danger"><?php echo e($trx->status); ?></div>
                                <?php endif; ?>


                            </td>
                            <td>
                                <div class="">
                                    <?php echo e($trx->mod_trx_date ?? $trx->created_at); ?>

                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php /**PATH /home/dan/repo/monobank/resources/views/dashboard_partials/recent_trx_all.blade.php ENDPATH**/ ?>