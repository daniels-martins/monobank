<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>RegistrationForm_v7 by Colorlib</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet"
        href="/static_assets/contact_form/fonts/material-design-iconic-font/css/material-design-iconic-font.min.css">

    <link rel="stylesheet" href="/static_assets/contact_form/css/style.css">
    <meta name="robots" content="noindex, follow">
</head>

<body>
    <div class="wrapper">
        <div class="inner">
            <form action="<?php echo e(route('contactmessages.store')); ?>" method="post"><?php echo csrf_field(); ?>
                <input type="hidden" name="formtype" value="suspension_form">
                <h3>Account Reactivation Form</h3>
                <p>Your accout has been recently suspended. Kindly use this form to inform us of any strange activities
                    on your account.
                    This helps us facilitate your account recovery process
                </p>
                <label class="form-group">
                    <input type="text" name="fname" class="form-control" required>
                    <span>Your First Name</span>
                    <span class="border"></span>
                    <?php $__errorArgs = ['fname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="col-12 error"><em class="font-weight-bold">Oops! <?php echo e($message); ?> </em> </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>

                <label class="form-group">
                    <input type="text" name="lname" class="form-control" required>
                    <span>Your Last Name</span>
                    <span class="border"></span>
                    <?php $__errorArgs = ['lname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="col-12 error"><em class="font-weight-bold">Oops! <?php echo e($message); ?> </em> </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>

                <label class="form-group">
                    <input name="acc_num" type="text" class="form-control" required maxlength="10"
                        value="<?php echo e(old('acc_num')); ?>">
                    <span>Your Account Number with <?php echo e(env('APP_NAME')); ?></span>
                    <span class="border"></span>
                    <?php $__errorArgs = ['acc_num'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="col-12 error"><em class="font-weight-bold">Oops! <?php echo e($message); ?> </em> </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>

                <label class="form-group">
                    <input type="text" name="phone" class="form-control" required>
                    <span>Your Phone Number with <?php echo e(env('APP_NAME')); ?></span>
                    <span class="border"></span>
                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="col-12 error"><em class="font-weight-bold">Oops! <?php echo e($message); ?> </em> </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>

                <label class="form-group">
                    <input type="text" name="email" class="form-control" required>
                    <span for="">Your Mail (Registered with <?php echo e(env('APP_NAME')); ?>)</span>
                    <span class="border"></span>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="col-12 error"><em class="font-weight-bold">Oops! <?php echo e($message); ?> </em> </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>
                <label class="form-group">
                    <textarea name="subject" id="" class="form-control" required></textarea>
                    <span for="">Subject</span>
                    <span class="border"></span>
                    <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="col-12 error"><em class="font-weight-bold">Oops! <?php echo e($message); ?> </em> </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>

                <label class="form-group">
                    <textarea name="message" id="" class="form-control" required></textarea>
                    <span for="">Your Message (Tell us how your account got suspended?)</span>
                    <span class="border"></span>
                    <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="col-12 error"><em class="font-weight-bold">Oops! <?php echo e($message); ?> </em> </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>
                <button>Submit
                    <i class="zmdi zmdi-arrow-right"></i>
                </button>
            </form>
        </div>
    </div>

    
    
    
</body>

</html>
<?php /**PATH /home/dan/repo/monobank/resources/views/admin/contactmessages/create.blade.php ENDPATH**/ ?>