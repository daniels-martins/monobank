<!DOCTYPE html>
<html lang="en">

<head>
    <title>Bluebird Bank| Experience banking made easy</title>
    <meta charset="UTF-8" />
    <meta name="description" content="Bluebird Global Express" />
    <meta name="keywords" content="banks, html" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    
    <link href="/static_assets/favicon_io/apple-touch-icon.png" rel="shortcut icon" />
    <link href="/static_assets/favicon_io/favicon-32x32.png" rel="shortcut icon" />
    <link rel="icon" type="image/x-icon" href="/static_assets/favicon_io/favicon-32x32.png">
    
    <link href="/static_assets/favicon_io/favicon.ico" rel="shortcut icon" />

    <link
        href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i&display=swap"
        rel="stylesheet" />

    <link rel="stylesheet" href="/static_assets/website/css/bootstrap.min.css" />
    <link rel="stylesheet" href="/static_assets/website/css/font-awesome.min.css" />
    <link rel="stylesheet" href="/static_assets/website/css/owl.carousel.min.css" />
    <link rel="stylesheet" href="/static_assets/website/css/flaticon.css" />
    <link rel="stylesheet" href="/static_assets/website/css/jquery-ui.min.css" />
    <link rel="stylesheet" href="/static_assets/website/css/slicknav.min.css" />

    <link rel="stylesheet" href="/static_assets/website/css/style.css" />
    <style>
        .my-1 {
            margin-top: 1em;
            margin-bottom: 1em;
        }

        .my-2 {
            margin-top: 2em;
            margin-bottom: 2em;
        }

        .my-3 {
            margin-top: 3em;
            margin-bottom: 3em;
        }

        .my-4 {
            margin-top: 4em;
            margin-bottom: 4em;
        }

        .my-5 {
            margin-top: 5em;
            margin-bottom: 5em;
        }
    </style>


    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body>
    <div id="preloder">
        <div class="loader"></div>
    </div>

    <header class="header-section">
        <a href="/" class="site-logo">
            
            
            <div class="" style="background: whitesmoke; padding: .4em .012em; margin-top: -1.31em;">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.application-logo','data' => ['width' => 85]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('application-logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['width' => 85]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </div>
        </a>
        <nav class="header-nav">
            <ul class="main-menu">
                <li><a href="<?php echo e(route('bank-homepage')); ?>" class="
                  <?php echo e(Route::currentRouteName() == 'bank-homepage' ? 'active' : ''); ?>">Home</a></li>
                <!-- <li><a href="news.html">News</a></li> -->
                <li><a href="<?php echo e(route('bank-loan')); ?>" class="<?php echo e(Route::currentRouteName() == 'bank-loan' ? 'active' : ''); ?>"">Apply For A Loan Today</a></li>
                <li><a href="<?php echo e(route('bank-about')); ?>" class="<?php echo e(Route::currentRouteName() == 'bank-about' ? 'active' : ''); ?>"">About Us</a></li>
                <li><a href="<?php echo e(route('bank-contact')); ?>" class="<?php echo e(Route::currentRouteName() == 'bank-contact' ? 'active' : ''); ?>"">Contact</a></li>
                <li><a href="<?php echo e(route('register')); ?>" class="">Sign Up / Account</a></li>
            </ul>
            <div class="header-right">
                <span
                 class="hr-btn"><i class="flaticon-029-telephone-1"></i>Call us now!
                </span>
                <div class="hr-btn hr-btn-2">+1 (619) 483-2333</div>

            </div>
        </nav>
    </header>
<?php /**PATH /home/dan/repo/monobank/resources/views/admin/partials/www/header.blade.php ENDPATH**/ ?>