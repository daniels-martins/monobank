<?php echo $__env->make('admin.partials.www.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="page-top-section set-bg" data-setbg="/static_assets/website/img/loans/1.jpg">
    <div class="container">
        <h2>Contact</h2>
        <nav class="site-breadcrumb">
            <a class="sb-item" href="/">Home</a>
            <span class="sb-item active">Contact</span>
        </nav>
    </div>
</section>


<section class="contact-section spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-4">
                <div class="contact-text">
                    <h2>Get in touch</h2>
                    <p>We are here to help you with any questions or concerns you may have about our products and
                        services. Whether you need assistance with opening an account, managing your finances, or
                        applying for a loan, our friendly and knowledgeable team is ready to assist you.

                        Please fill out the form below to get in touch with us, and we will respond to your inquiry as
                        soon as possible. We appreciate your feedback and look forward to hearing from you!</p>
                    <ul>
                        <li><i class="flaticon-032-placeholder"></i>PO Box 63, Winslow, NY 46540, USA</li>
                        <li><i class="flaticon-029-telephone-1"></i> +1 (619) 483-2333</li>
                        <li><i class="flaticon-025-arroba"></i>info@bluebirdglobals.com</li>
                        <li><i class="flaticon-038-wall-clock"></i>Everyday: 06:00 -22:00</li>
                    </ul>
                    
                </div>
            </div>
            <div class="col-lg-8">
                <form class="contact-form" method="post" action="<?php echo e(route('contactmessages.store')); ?>"><?php echo csrf_field(); ?>
                    <div class="row my-1">
                        <div class="col-md-6">
                            <input required type="text" placeholder="Your Name" name="fullname">
                            <?php $__errorArgs = ['fullname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="error"><b>Oops! <?php echo e($message); ?></b></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6">
                            <input required type="text" placeholder="Your E-mail" name="email">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="error"><b>Oops! <?php echo e($message); ?></b></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-md-12 my-1">
                            <input required type="text" placeholder="Phone" name="phone" minlength="10" maxlength="15">
                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="error"><b>Oops! <?php echo e($message); ?></b></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-md-12 my-1">
                            <input required type="text" placeholder="Subject" name="subject">
                            <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="error"><b>Oops! <?php echo e($message); ?></b></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <textarea required placeholder="Your Message" name="message"></textarea>
                        <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="error"><b>Oops! <?php echo e($message); ?></b></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="my-3">
                            <button class="site-btn">send message</button>
                        </div>
                    </div>
            </div>
            </form>
        </div>
    </div>
    
    </div>
</section>

<!-- calculate credit score placeholder -->

<?php echo $__env->make('admin.partials.www.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/dan/repo/monobank/resources/views/website/www-contact.blade.php ENDPATH**/ ?>