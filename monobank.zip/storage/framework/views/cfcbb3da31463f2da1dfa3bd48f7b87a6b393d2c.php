<div class="header-navbar navbar-expand-sm navbar navbar-horizontal navbar-fixed navbar-dark navbar-without-dd-arrow navbar-shadow"
    role="navigation" data-menu="menu-wrapper">
    <div class="navbar-container main-menu-content" data-menu="menu-container">
        <ul class="nav navbar-nav" id="main-menu-navigation" data-menu="menu-navigation">
            <li class="nav-item ml-_1  bg-black"><a class="nav-link  <?php if(Route::currentRoutename() == 'dashboard'): ?> bg-danger <?php endif; ?>"
                    href="<?php echo e(route('dashboard')); ?>"><i class="la la-bank text-sm"></i><span>Account Dashboard</span></a>
            </li>
            

            <li class="nav-item mx-2  <?php if(Route::currentRoutename() == 'accounts.index'): ?> bg-danger <?php endif; ?>">
                <a class="nav-link  text-sm <?php if(Route::currentRoutename() == 'accounts.index'): ?> text-white <?php endif; ?>"
                    href="<?php echo e(route('accounts.index')); ?>">Account Information</a>
            </li>

            


            <li class=" <?php if(Route::currentRoutename() == 'cards.index'): ?> bg-danger <?php endif; ?> nav-item mx-2 text-sm">
                <a class="text-sm nav-link <?php if(Route::currentRoutename() == 'cards.index'): ?> text-white <?php endif; ?> "
                    href="<?php echo e(route('cards.index')); ?>">Cards</a>
            </li>
            
            <li class="dropdown <?php if(Route::currentRoutename() == 'transactions.index'): ?> bg-danger <?php endif; ?>  nav-item mx-2">
                <a class="text-sm <?php if(Route::currentRoutename() == 'transactions.index'): ?> text-white <?php endif; ?> nav-link"
                    href="<?php echo e(route('transactions.index')); ?>">Transactions</a>
            </li>

            <li class="<?php if(Route::currentRoutename() == 'profile.edit'): ?> bg-danger <?php endif; ?>  nav-item mx-2 ">
                <a class="text-sm nav-link <?php if(Route::currentRoutename() == 'profile.edit'): ?> text-white <?php endif; ?>"
                    href="<?php echo e(route('profile.edit')); ?>">Profile</a>
            </li>

            <li class="<?php if(Route::currentRoutename() == 'payments.create'): ?> bg-danger <?php endif; ?>   nav-item mx-2">
                <a class="text-sm nav-link  <?php if(Route::currentRoutename() == 'payments.create'): ?> text-white <?php endif; ?>"
                    href="<?php echo e(route('payments.create')); ?>">Transfer</a>
            </li>

            <li class="nav-item mx-2 <?php if(Route::currentRoutename() == 'password.edit'): ?> bg-danger <?php endif; ?>">
               <a class="text-sm nav-link  <?php if(Route::currentRoutename() == 'password.edit'): ?> text-white <?php endif; ?>"
                   href="<?php echo e(route('password.edit')); ?>">
                   Change Password
               </a>
           </li>

           <li class="nav-item mx-2 <?php if(Route::currentRoutename() == 'photo.create'): ?>') bg-danger <?php endif; ?>">
            <a class="text-sm nav-link  <?php if(Route::currentRoutename() == 'photo.create'): ?>') text-white <?php endif; ?>"
                href="<?php echo e(route('photo.create')); ?>">
                Upload Photo
            </a>
        </li>


            <div class="show-sm">

                <li class="nav-item mx-2 d-block ">
                    <a class="d-block d-sm-none text-white nav-link m-1 bg-danger" id="logout_facade">
                        <i class="ft-power"> Logout </i>
                    </a>
                </li>

                <li class="nav-item mx-2 <?php if(Route::currentRoutename() == 'password.edit'): ?> bg-danger <?php endif; ?>">
                    <form class='' action="<?php echo e(route('logout')); ?>" method="post" id="logout_form">
                        <?php echo csrf_field(); ?>
                    </form>
                    <button id="submitLogoutForm" class="btn-danger hidden" href="" type="submit"
                        form="logout_form"><i class="ft-power"></i>Logout</button>
                </li>
                <script>
                    document.querySelector('#logout_facade').addEventListener('click', function() {
                        alert('logout', 'submitLogoutForm')
                        document.querySelector('#submitLogoutForm').click();
                    });
                </script>

            </div>
        </ul>
    </div>
</div>
<?php /**PATH /home/dan/repo/monobank/resources/views/admin/partials/main_menu.blade.php ENDPATH**/ ?>