<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['width', 'height']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['width', 'height']); ?>
<?php foreach (array_filter((['width', 'height']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>



<img src="/static_assets/img/blue-bird-logo-1.svg"   alt="" width="<?php echo e($width ?? 100); ?>" height="<?php echo e($height ?? 62); ?>" />


<?php /**PATH /home/dan/repo/monobank/resources/views/components/application-logo.blade.php ENDPATH**/ ?>