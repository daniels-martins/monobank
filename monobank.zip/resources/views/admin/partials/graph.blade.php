 {{-- <div class="col-xl-9 col-lg-8 col-md-12">
     <div class="card">
         <div class="card-content">
             <div class="card card-shadow">
                 <div class="card-header card-header-transparent">
                     <h4 class="card-title">Transaction Reports</h4>
                     <ul class="nav nav-pills nav-pills-rounded chart-action float-right btn-group" role="group">
                         <li class="nav-item">
                             <a class="active nav-link" data-toggle="tab" href="#scoreLineToDay">Day</a>
                         </li>
                         <li class="nav-item">
                             <a class="nav-link" data-toggle="tab" href="#scoreLineToWeek">Week</a>
                         </li>
                         <li class="nav-item">
                             <a class="nav-link" data-toggle="tab" href="#scoreLineToMonth">Month</a>
                         </li>
                     </ul>
                 </div>
                 <div class="widget-content tab-content bg-white p-20">
                     <div class="ct-chart tab-pane active scoreLineShadow" id="scoreLineToDay">
                     </div>
                     <div class="ct-chart tab-pane scoreLineShadow" id="scoreLineToWeek"></div>
                     <div class="ct-chart tab-pane scoreLineShadow" id="scoreLineToMonth"></div>
                 </div>
             </div>
         </div>
     </div>
 </div> --}}
